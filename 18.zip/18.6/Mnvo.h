#include <iostream>

using namespace std;

class Iterator
{
  friend class Mnvo;
  
  public:
  Iterator()
  {
    elem=0;
  }
  Iterator(const Iterator&it)
  {
    elem=it.elem;
  }
  bool operator==(const Iterator&it)
  {
    return elem==it.elem;
  } 
  bool operator!=(const Iterator&it)
  {
    return elem!=it.elem;
  };
  void operator++()
  { 
    ++elem;
  };
  void operator--()
  {
    --elem;
  }
  int& operator *() const
  { 
    return*elem;
  } 

  int *elem;
};

class Mnvo
{
  public:

  Mnvo (int length, int k=0);
  Mnvo (Mnvo&);
  ~Mnvo ();
  Mnvo& operator = (Mnvo&);
  int operator () ();
  int& operator [] (int);
  Mnvo operator - (Mnvo);
  friend istream& operator>>(istream&,Mnvo&);
  friend ostream& operator<<(ostream&,const Mnvo&);

  Iterator first()
  {
    return beg;
  }
  Iterator last()
  {
    return end;
  }

  int size; 
  int*data;
  Iterator beg; 
  Iterator end;
};
