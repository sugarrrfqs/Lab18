/*
Стандартные алгоритмы STL

Задача 3
1.	Создать ассоциативный контейнер.
2.	Заполнить его элементами пользовательского типа (тип указан в варианте). Для пользовательского типа перегрузить необходимые операции.
3.	Заменить элементы в соответствии с заданием (использовать алгоритмы
replace_if(), replace_copy(), replace_copy_if(), fill()).
4.	Удалить элементы в соответствии с заданием (использовать алгоритмы
remove(),remove_if(), remove_copy_if(),remove_copy())
5.	Отсортировать контейнер по убыванию и по возрастанию ключевого поля (использовать алгоритм sort()).
6.	Найти в контейнере элемент с заданным ключевым полем (использовать
алгоритмы find(), find_if(), count(), count_if()).
7.	Выполнить задание варианта для полученного контейнера (использовать алгоритм
for_each()) .
8.		Для выполнения всех заданий использовать стандартные алгоритмы библиотеки STL.
Задача 3 
Ассоциативный контейнер - множество

3.	Заменить элементы большие среднего арифметического на минимальное значение контейнера.
4.	Отсортировать контейнер по убыванию и по возрастанию ключевого поля.
5.	Найти в контейнере элемент с заданным ключевым полем.
6.	Удалить минимальный элемент из контейнера.
7.	Каждый элемент разделить на максимальное значение контейнера.
*/


#include "Time.h" 
#include "Mnvo.h"
#include <vector>
#include <iostream> 
#include <algorithm>

using namespace std;

typedef vector<Time> TVector;
Time s;

bool greaterr(Time);
bool lless(Time,Time);
bool Equal_s(Time);
TVector make_vector();
void print_vector(TVector);
Time srednee(TVector);
void del(Time&);
void make_mnvo(Time*&, int);
TVector mnvoToVector(Time*&, int);
int main()
{
  
// Создание множества
  int n; 
  cout<<"Введите количество элементов: "; 
  cin>>n; 
  TVector v;
  Time*mas= new Time[n];
  cout<<"Введите ваше множество\n";
  make_mnvo(mas,n); 
  cout<<'\n';
  v=mnvoToVector(mas,n);
  print_vector(v);
//
cout<<"----------------------------------------------------------------------------\n";
// Заменяем элементы большие среднего арифметического на максимальное значение контейнера
  TVector::iterator i;
  i=max_element(v.begin(),v.end()); 
  cout<<"Максимальный элемент="<<*(i)<<endl;
  Time m=*(i);
  s=srednee(v);
  cout<<"Среднее="<<s<<endl;
  replace_if(v.begin(),v.end(), greaterr,m); 
  cout<<"Замена"<<endl;
  print_vector(v);
//
cout<<"----------------------------------------------------------------------------\n";
// Cортируем контейнер по убыванию и по возрастанию
  cout<<"Сортировка по убыванию:\n";
  sort(v.begin(),v.end(), lless);
  print_vector(v);
  
  cout<<"Сортировка по возрастанию:\n"; 
  sort(v.begin(),v.end()); 
  print_vector(v);
//
cout<<"----------------------------------------------------------------------------\n";
// Поиск по ключу
  cout<<"Поиск по ключу"<<endl; 
  cin>>s;
  i=find_if(v.begin(),v.end(),Equal_s); 
  if(i!=v.end())
  cout<<*(i)<<endl;
  else
  cout<<"Элемента нет в последовательности"<<endl;
//
cout<<"----------------------------------------------------------------------------\n";
// Удаление минимального элемента из контейнера
  cout<<"Удаление минимального элемента из контейнера\n"; 
  i=min_element(v.begin(),v.end()); 
  s=*i;
  i=remove_if(v.begin(),v.end(),Equal_s); 
  v.erase(i,v.end());
  print_vector(v);
//
cout<<"----------------------------------------------------------------------------\n";
// Каждый элемент делим на максимальное значение контейнера
  cout<<"Деление"<<endl; 
  i=max_element(v.begin(),v.end()); 
  s=*i;
  for_each(v.begin(),v.end(),del);
  print_vector(v);
//
}

TVector make_vector(int n)
{
  Time a;
  TVector v;
  for(int i=0;i<n;i++)
  {
    cin>>a; 
    v.push_back(a);
  }
  return v;
}

void print_vector(TVector v)
{
  for(int i=0;i<v.size();i++) cout<<v[i]<<endl; 
  cout<<endl;
}

Time srednee(TVector v)
{
  Time s=v[0];
  for(int i=1;i<v.size();i++) s=s+v[i];
  int n=v.size();
  return s/n;
}

void del(Time& t)
{
  t=t/s;
}

bool greaterr(Time t)
{
  if (t>s) return true; 
  else return false;
}

bool lless(Time t1,Time t2)
{
  if (t1>t2) return true; 
  else return false;
}

bool Equal_s(Time t)
{
  return t==s;
}

void make_mnvo(Time*& A, int length)
{
  int i,j;
  Time el;
  Time h(666,0);
  cin>> A[0];
  for (i = 1; i < length; i++)
	{
		cin >> el;
		if (el > A[i-1])
		{
			A[i] = el;
		}
		else
		{
			j = i-1;
			while (el < A[j])
			{
				A[j + 1] = A[j];
				A[j] = h;
				j--;
		  }
			A[j + 1] = el;
		}
	}
}

TVector mnvoToVector(Time*& mas,int n)
{
  TVector v;
  for (int i=0; i<n; i++)
  {
    v.push_back(mas[i]);
  }
  return v;
}
