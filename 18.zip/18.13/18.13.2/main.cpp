/*
Стандартные алгоритмы STL

Задача 2.
1.	Создать адаптер контейнера.
2.	Заполнить его элементами пользовательского типа (тип указан в варианте). Для пользовательского типа перегрузить необходимые операции.
3.	Заменить элементы в соответствии с заданием (использовать алгоритмы
replace_if(), replace_copy(), replace_copy_if(), fill()).
4.	Удалить элементы в соответствии с заданием (использовать алгоритмы
remove(),remove_if(), remove_copy_if(),remove_copy())
5.	Отсортировать контейнер по убыванию и по возрастанию ключевого поля (использовать алгоритм sort()).
6.	Найти в контейнере элемент с заданным ключевым полем (использоватьалгоритмы find(), find_if(), count(), count_if()).
7.	Выполнить задание варианта для полученного контейнера (использовать алгоритм
for_each()) .
8.		Для выполнения всех заданий использовать стандартные алгоритмы библиотеки STL.
Задача 2
Адаптер контейнера – стек

3.	Заменить элементы большие среднего арифметического на максимальное значение контейнера.
4.	Отсортировать контейнер по убыванию и по возрастанию ключевого поля.
5.	Найти в контейнере элемент с заданным ключевым полем.
6.	Удалить минимальный элемент из контейнера.
7.	Каждый элемент разделить на максимальное значение контейнера.
*/

#include "Time.h" 
#include <iostream> 
#include <algorithm>
#include <stack>
#include <vector>

using namespace std;

typedef stack<Time> TStack;
typedef vector<Time> TVector;

Time s;

bool greaterr(Time);
bool lless(Time,Time);
bool Equal_s(Time);
TStack make_stack(int);
void print_stack(TStack);
Time srednee(TVector);
void del(Time&);
TVector stackToVector(TStack);
TStack vectorToStack(TVector);

int main()
{
  
// Создание стека
  int n; 
  cout<<"Введите количество элементов: "; 
  cin>>n; 
  TStack st;
  st=make_stack(n); 
  print_stack(st);
//
cout<<"----------------------------------------------------------------------------\n";
// Заменяем элементы большие среднего арифметического на максимальное значение контейнера
  TVector::iterator i;
  TVector v;
  v=stackToVector(st);
  i=max_element(v.begin(),v.end()); 
  cout<<"Максимальный элемент="<<*(i)<<endl;
  Time m=*(i);
  s=srednee(v);
  cout<<"Среднее="<<s<<endl;
  replace_if(v.begin(),v.end(), greaterr,m); 
  cout<<"Замена"<<endl;
  st=vectorToStack(v);
  print_stack(st);
//
cout<<"----------------------------------------------------------------------------\n";
// Cортируем контейнер по убыванию и по возрастанию
  cout<<"Сортировка по убыванию:\n";
  v=stackToVector(st);
  sort(v.begin(),v.end(), lless);
  st=vectorToStack(v);
  print_stack(st);
  
  cout<<"Сортировка по возрастанию:\n";
  v=stackToVector(st); 
  sort(v.begin(),v.end()); 
  st=vectorToStack(v);
  print_stack(st);
//
cout<<"----------------------------------------------------------------------------\n";
// Поиск по ключу
  cout<<"Поиск по ключу"<<endl; 
  cin>>s;
  v=stackToVector(st);
  i=find_if(v.begin(),v.end(),Equal_s);
  st=vectorToStack(v); 
  if(i!=v.end())
  cout<<*(i)<<endl;
  else
  cout<<"Элемента нет в последовательности"<<endl;
//
cout<<"----------------------------------------------------------------------------\n";
// Удаление минимального элемента из контейнера
  cout<<"Удаление минимального элемента из контейнера\n";
  v=stackToVector(st); 
  i=min_element(v.begin(),v.end()); 
  s=*i;
  i=remove_if(v.begin(),v.end(),Equal_s); 
  v.erase(i,v.end());
  st=vectorToStack(v);
  print_stack(st);
//
cout<<"----------------------------------------------------------------------------\n";
// Каждый элемент делим на максимальное значение контейнера
  cout<<"Деление"<<endl; 
  v=stackToVector(st);
  i=max_element(v.begin(),v.end()); 
  s=*i;
  for_each(v.begin(),v.end(),del);
  st=vectorToStack(v);
  print_stack(st);
//
}

TStack make_stack(int n)
{
  Time a;
  TStack v;
  for(int i=0;i<n;i++)
  {
    cin>>a; 
    v.push(a);
  }
  return v;
}

void print_stack(TStack v)
{
  int n=v.size();
  for(int i=0;i<n;i++) 
  {
    cout<<v.top()<<endl; 
    v.pop();
  }
  cout<<endl;
}

Time srednee(TVector v)
{
  Time s=v[0];
  for(int i=1;i<v.size();i++) s=s+v[i];
  int n=v.size();
  return s/n;
}

void del(Time& t)
{
  t=t/s;
}

bool greaterr(Time t)
{
  if (t>s) return true; 
  else return false;
}

bool lless(Time t1,Time t2)
{
  if (t1>t2) return true; 
  else return false;
}

bool Equal_s(Time t)
{
  return t==s;
}

TVector stackToVector(TStack st)
{
  TVector v;
  int i=0;
  while (!st.empty())
  {
    v.push_back(st.top());
    st.pop();
    i++;
  }
  return v;
}

TStack vectorToStack(TVector v)
{
  TStack st;
  int i=0;
  while (!v.empty())
  {
    st.push(v[v.size()-1]);
    v.erase(v.end());
  }
  return st;
}
