#include "Time.h" 
#include <iostream> 

using namespace std;

//перегрузка операции присваивания 
Time&Time::operator=(const Time&t)
{
  //проверка на самоприсваивание 
  if(&t==this) return *this; 
  min=t.min;
  sec=t.sec; 
  return *this;
}

//перегрузка префиксной операции инкремент 
Time&Time::operator++()
{
  int temp=min*60+sec; 
  temp++; 
  min=temp/60; 
  sec=temp%60;
  return *this;
}

//перегрузка постфиксной операции инкремент 
Time Time::operator ++(int)
{
  int temp=min*60+sec; 
  temp++;
  Time t(min,sec); 
  min=temp/60; 
  sec=temp%60; 
  return t;
}

//перегрузка операции сложения 
Time Time::operator+(const Time&t)
{
  int temp1=min*60+sec;
  int temp2=t.min*60+t.sec;
  Time p;
  p.min=(temp1+temp2)/60;
  p.sec=(temp1+temp2)%60;
  return p;
}

Time Time::operator/(const int t)
{
  int temps=sec;
  int tempm=min;
  Time p;
  p.min= tempm/t;
  p.sec= temps/t;
  return p;
}
#include "Time.h" 
#include <iostream> 

using namespace std;

//перегрузка операции присваивания 
Time&Time::operator=(const Time&t)
{
  min=t.min;
  sec=t.sec; 
  return *this;
}

//перегрузка операции инкремент (префикс)
Time&Time::operator++()
{
  int temp=min*60+sec; 
  temp++; 
  min=temp/60; 
  sec=temp%60;
  return *this;
}

//перегрузка операции инкремент (постфикс)
Time Time::operator ++(int)
{
  int temp=min*60+sec; 
  temp++;
  Time t(min,sec); 
  min=temp/60; 
  sec=temp%60; 
  return t;
}

//перегрузка операции сложения 
Time Time::operator+(const Time&t)
{
  int temp1=min*60+sec;
  int temp2=t.min*60+t.sec;
  Time p;
  p.min=(temp1+temp2)/60;
  p.sec=(temp1+temp2)%60;
  return p;
}


//перегрузка операции деления на int
Time Time::operator/(const int t)
{
  int temps=sec;
  int tempm=min;
  Time p;
  if (t!=0)  p.min= tempm/t;
  if (t!=0) p.sec= temps/t;
  return p;
}

//перегрузка операции деления на Time
Time Time::operator/(const Time&t)
{
  int temps=sec;
  int tempm=min;
  Time p;
  if (t.min!=0) p.min= tempm/t.min;
  else p.min=tempm;
  if (t.sec!=0) p.sec= temps/t.sec;
  else p.sec=temps;
  return p;
}

//перегрузка операции меньше
bool Time::operator<(const Time&t)
{
  if (min==t.min)
  {
    if (sec<t.sec)
    {
      return true;
    }
    else 
    {
      return false;
    }
  }
  else
  {
    if (min<t.min)
    {
      return true;
    }
    else 
    {
      return false;
    }
  }
}

//перегрузка операции больше
bool Time::operator>(const Time&t)
{
  if (min==t.min)
  {
    if (sec>t.sec)
    {
      return true;
    }
    else 
    {
      return false;
    }
  }
  else
  {
    if (min>t.min)
    {
      return true;
    }
    else 
    {
      return false;
    }
  }
}


//перегрузка операции сравнения
bool Time::operator==(const Time&t)
{
  if (t.sec==sec && t.min==min)
  {
    return true;
  }
  else
  {
    return false;
  }
}

//перегрузка глобальной функции-операции ввода 
istream&operator>>(istream&in, Time&t)
{
cout<<"Минуты: "; 
in>>t.min; 
cout<<"Секунды: "; 
in>>t.sec; 
return in;
}

//перегрузка глобальной функции-операции вывода 
ostream&operator<<(ostream&out, const Time&t)
{
  return (out<<t.min<<" : "<<t.sec);
}


