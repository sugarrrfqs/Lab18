#include <iostream>
#include "Mnvo.h"

using namespace std;

Mnvo::Mnvo(int s,int k)
{
  if (s<=0) throw error("Длина меньше 1");
  if (s>1000) throw error ("Длина больше 1000");
  size=s;
  data=new int[size]; 
  for(int i=0;i<size;i++) data[i]=k;
  beg.elem=&data[0];
  end.elem=&data[s-1];
}

Mnvo::Mnvo(Mnvo& a)
{
  size=a.size; 
  data=new int[size];
  for(int i=0;i<size;i++) data[i]=a.data[i];
  beg.elem=&data[0];
  end.elem=&data[0];
}

Mnvo::~Mnvo()
{
  delete[]data; 
  data=0;
}

Mnvo &Mnvo::operator=(Mnvo&a)
{
  if(this==&a) return *this; 
  size=a.size;
  if (data!=0) delete[]data; 
  data=new int[size]; 
  for(int i=0;i<size;i++) data[i]=a.data[i]; 
  return *this;
}

int& Mnvo::operator [] (int index)
{
  if (index<size && index>=-1) return data[index]; 
  else throw error("Неподходящий индекс");
}

int Mnvo::operator ()()
{
  return size;
}

Mnvo Mnvo::operator - (Mnvo a)
{
  bool f;
  if ((*this).size<=0) throw error("Невозможно уменьшить множество, его размер меньше 1");
  Mnvo mas((*this).size);

  for (int i=0; i<a.size; i++)
  {
    f=false;
    for (int j=0; j<(*this).size; j++)
    {
      if (a[i]==(*this)[j] && !f)
      {
        (*this)[j]=-666;
        f=true;
      }
    }
  }
  int l=0;
  for (int k=0; k<(*this).size; k++)
  {
    if ((*this)[k]!=-666)
    {
      mas.data[l]=(*this)[k];
      l++;
    }
  }
  
  return mas; 
}

Mnvo& Mnvo::operator--()
{
  if (size==0) throw error("Длина уменьшаемого множества меньше 1");
  (*this)[size-1]=0;
  size--;
  return (*this);
}

ostream&operator<<(ostream&out,const Mnvo&a)
{
  cout<<"Множество: ";
  for(int i=0;i<a.size;++i) 
  {
    if (a.data[i]!=-666) out<<a.data[i]<<" ";
  }
  return out;
}

istream&operator>>(istream&in,Mnvo&a)
{
  for(int i=0;i<a.size;++i) in>>a.data[i];
  return in;
}

