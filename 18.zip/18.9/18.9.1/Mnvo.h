#pragma once

#include <iostream>

using namespace std;

template <class T>
class Mnvo
{
    public:

	Mnvo(int length, T k);
	Mnvo(Mnvo<T>&);
	~Mnvo();
	Mnvo& operator = (Mnvo<T>&);
	int operator () ();
	T& operator [] (int);
	Mnvo operator - (Mnvo<T>);
	friend istream& operator >> <>(istream&in, Mnvo<T>&a);
	friend ostream& operator << <>(ostream&out, const Mnvo<T>&a);

	int size;
	T*data;
  
};


template <class T>
Mnvo<T>::Mnvo(int s, T k)
{
	size = s;
#include <iostream>

using namespace std;

class Iterator
{
  friend class Mnvo;
  
  public:

  Iterator()
  {
    elem=0;
  }
  Iterator(const Iterator&it)
  {
    elem=it.elem;
  }

  bool operator==(const Iterator&it)
  {
    return elem==it.elem;
  } 
  bool operator!=(const Iterator&it)
  {
    return elem!=it.elem;
  };
  void operator++()
  { 
    ++elem;
  };
  void operator--()
  {
    --elem;
  }

  int& operator *() const
  { 
    return*elem;
  } 

  int *elem;
};

class Mnvo
{
  public:

  Mnvo (int length, int k=0);
  Mnvo (Mnvo&);
  ~Mnvo ();
  Mnvo& operator = (Mnvo&);
  int operator () ();
  int& operator [] (int);
  Mnvo operator - (Mnvo);
  Mnvo& operator--();
  friend istream& operator>>(istream&,Mnvo&);
  friend ostream& operator<<(ostream&,const Mnvo&);

  Iterator first()
  {
    return beg;
  }
  Iterator last()
  {
    return end;
  }

  int size; 
  int*data;
  Iterator beg; 
  Iterator end;
};
