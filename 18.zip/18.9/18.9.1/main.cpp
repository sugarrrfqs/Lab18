/*
Обработка исключительных ситуаций

1.	Реализовать класс, перегрузить для него операции, указанные в варианте.
2.	Определить исключительные ситуации.
3.	Предусмотреть генерацию исключительных ситуаций.

Класс- контейнер МНОЖЕСТВО с элементами типа int. Реализовать операции:
[] – доступа по индексу;
() – определение размера вектора;
- – разность множеств;
-- – удаление элемента из множества.

Вариант реализации: 1, 2
*/

#include <iostream>
#include "Mnvo.h"

using namespace std;

void make_mnvo(Mnvo&, int);

int main ()
{
  try
  {
    int size, ind,move;
    cout<<"Введите размер вашего множества: ";
    cin>>size;
    Mnvo mas(size);
    cout<<"Введите ваше множество\n";
    cin>>mas[0];
    make_mnvo(mas,size);
    cout<<mas;

    cout<<"\n1- Вывод элемента по индексу\n2- Разность множеств\n3- Уменьшение массива\nВаша команда: ";
    cin>>move;
    switch (move)
    {

    case 1:
    cout<<"\nВведите индекс элемента, который вы хотите вывести: ";
    cin>>ind;
    cout<<mas[ind]<<" - ваш элемент\n";
    break;
    
    case 2:
    cout<<"Введите размер вашего множества, которое вы хотите вычесть: ";
    cin>>size;
    Mnvo newM(size);
    cout<<"Введите ваше множество, которое вы хотите вычесть: ";
    cin>>newM[0];
    make_mnvo(newM,size);
    cout<<mas<<"\n-\n"<<newM<<"\n=\n";
    mas-newM;
    cout<<mas<<'\n';
    break;
    
    }
    if (move ==3) 
    {
      cout<<"Уменьшение массива до появления ошибки:\n";
      while (true)
      {
        cout<<mas<<'\n';
        --mas;
      }
    }
    if (move!=1 &&move!=2 && move!=3) throw 5;
    }
  catch (int)
  {
    cout<<"Ошибка";
  }
  
}

void make_mnvo(Mnvo& A, int length)
{
  int i,j,el;

  for (i = 1; i < length; i++)
	{
		cin >> el;
		if (el > A[i-1])
		{
			A[i] = el;
		}
		else
		{
			j = i-1;
			while (el < A[j])
			{
				A[j + 1] = A[j];
				A[j] = 0;
				j--;
		  }
			A[j + 1] = el;
		}
	}
}

