#pragma once

#include <iostream>
#include "Triada.h"

using namespace std;

class Date:public Triada
{
  public:

  void  inc_date (int n)
  {
    int k;
    k=first+second*30+third*360;
    k+=n;
    first=k%30;
    second=(k%360)/30;
    third=k/360;
  }
  
  void Show ()
  {
    cout<<first<<"."<<second<<"."<<third<<'\n';
  }

  friend istream& operator>>(istream&in, Date&m); 
  friend ostream& operator<<(ostream&out, const Date&m);
};