#pragma once
#include <iostream>

class Abstract
{
  public:

  Abstract (void){}
  ~Abstract (void){}
  virtual void Show () =0;
};