#include "Money.h"
#include <iostream>

using namespace std;

Money &Money::operator--()
{
  kop=0;
  return *this;
}

Money Money::operator--(int)
{
  Money m (rub, kop);
  kop=0;
  return m;
}

bool Money::operator==(Money &m)
{
  if (m.rub==rub && m.kop==kop)
  {
    return true;
  }
  else 
  {
    return false;
  }
}

bool Money::operator!=(Money &m)
{
  if (m.rub==rub && m.kop==kop)
  {
    return false;
  }
  else 
  {
    return true;
  }
}

bool Money::operator < (Money&m)
{
  if (rub<m.rub)
  {
    return true;
  }
  else 
  {
    if (rub>m.rub)
    {
      return false;
    }
    else 
    {
      if (kop<m.kop)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }
}

Money Money::operator+(Money& m)
{
  Money tmp;
  tmp.rub=rub+m.rub;
  if (kop+m.kop>=100)
  {
    tmp.kop=kop+m.kop-100;
    tmp.rub++;
  }
  else 
  {
    tmp.kop=kop+m.kop;
  }
  return tmp;
}

istream&operator>>(istream&in, Money& m) 
{
  cout<<"Рубли: ";
  in>>m.rub;
  cout<<"Копейки: ";
  in>>m.kop;
  return in;
} 

ostream&operator<<(ostream&out, const Money&m)
{
  return (out<<m.rub<<","<<m.kop);
}

fstream& operator>>(fstream& fin, Money&m)
{
  fin>>m.rub; 
  fin>>m.kop; 
  return fin;
}

fstream& operator<<(fstream& fout, const Money &m)
{
  fout<<m.rub<<"\n"<<m.kop<<"\n"; 
  return fout;
}
