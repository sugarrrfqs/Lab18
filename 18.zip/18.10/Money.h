#pragma once 

#include <iostream>
#include <fstream>

using namespace std;

class Money
{
  long rub;
  int kop;

  public:
  
  Money ()
  {
    rub=0;
    kop=0;
  }

  Money (long r, int k)
  {
    rub=r;
    kop=k;
  }

  Money (Money &m)
  {
    rub=m.rub;
    kop=m.kop;
  }

  ~Money(){}
 
  long get_rub ()
  {
    return rub;
  }
   
  int get_kop ()
  {
    return kop;
  }

  void set_rub (long r)
  {
    rub=r;
  }
  
  void set_kop (int k)
  {
    kop=k;
  }

  Money& operator--();
  Money operator--(int);
  bool operator==(Money&);
  bool operator!=(Money &);
  bool operator<(Money&);
  Money operator+(Money&);

  friend istream& operator>>(istream&in, Money&m); 
  friend ostream& operator<<(ostream&out, const Money&m);

  friend fstream& operator>>(fstream &fin, Money &m);
  friend fstream& operator <<(fstream &fout, const Money&m);

};
