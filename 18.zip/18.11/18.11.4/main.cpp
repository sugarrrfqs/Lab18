/*
Последовательные контейнеры

Задача 4
1.	Создать адаптер контейнера.
2.	Заполнить его элементами пользовательского типа (тип указан в варианте). Для пользовательского типа перегрузить необходимые операции.
3.	Добавить элементы в соответствии с заданием
4.	Удалить элементы в соответствии с заданием.
5.	Выполнить задание варианта для полученного контейнера.
6.	Выполнение всех заданий оформить в виде глобальных функций.
Задача 4
Адаптер контейнера – очередь.

Задание 3	
Найти минимальный элемент и добавить его на заданную позицию
контейнера	
Задание 4
Найти элементы большие среднего арифметического и
удалить их из контейнера
Задание 5
Каждый элемент домножить на максимальный элемент контейнера
*/

#include <iostream> 
#include <vector> 
#include <queue>
#include <cstdlib>
#include <vector> 
#include "Money.h"

using namespace std;

typedef vector<Money> vctr;
typedef queue<Money> que;

vctr queToVector(que);
que vectorToQue(vctr);

que makeQue(int);
void printQue(que);
void addMin(vctr&, int);
void delAboveAverage (vctr&);
void multiplyByMax(vctr&);

int main()
{
  try
  {
    vctr v;
    que q;
    int n;
  // 1, 2
    cout<<"Введите длину очереди: "; 
    cin>>n; 
    if (n<1) throw 0;
    q=makeQue(n);
    printQue(q);
  //
  cout<<"----------------------------------------------------------------------------\n";
  
  // 3
    cout<<"Добавление минимального элемента на позицию N, введите N:";
    cin>>n;
    if (n<1) throw 0;
    v=queToVector(q);
    addMin(v, n);
    q=vectorToQue(v);
    printQue(q);
  //
  cout<<"----------------------------------------------------------------------------\n";
  
  //4
    cout<<"Найти элементы большие среднего арифметического и удалить их из контейнера\n";
    v=queToVector(q);
    delAboveAverage(v);
    q=vectorToQue(v);
    printQue(q);
  //
  cout<<"----------------------------------------------------------------------------\n";
  // 5
    cout<<"Каждый элемент домножить на максимальный элемент контейнера\n";
    v=queToVector(q);
    multiplyByMax(v);
    q=vectorToQue(v);
    printQue(q);
  //
  
  }

  catch(int)
  {
    cout<<"Ошибка";
  }
}

que makeQue(int n)
{ 
  vctr v;
  for(int i=0;i<n;i++)
  {
    long a = rand()%100; 
    int b = rand()%100;
    Money c(a,b);
    v.push_back(c);
  }
  que q=vectorToQue(v);
  return q;
}
 
void printQue(que q)
{
  vctr v=queToVector(q);
  cout<<"\nОчередь: ";
  for (int i=0; i<v.size(); i++) 
  {
    cout<<v[i]<<"  ";
  }
  cout<<'\n';
  cout<<endl;
}

void addMin(vctr& v, int n)
{
  Money minn;
  minn=v[0];

  for (int i=1; i<v.size(); i++)
  {
    if (v[i]<minn) minn=v[i];
  }
  v.insert(v.begin()+n, minn);
}

void delAboveAverage (vctr& v)
{
  Money sum;
  for (int i=0; i<v.size(); i++)
  {
    sum+v[i];
  }
  sum/v.size();
  cout<<"Среднее = "<<sum<<'\n'<<"Элементы, больше среднего: ";
  
  for (int i=0; i<v.size(); i++)
  {
    if (v[i]>sum) 
    {
      cout<<v[i]<<' ';
      v.erase (v.begin()+i);
      i--;
    }
  }
}

void multiplyByMax(vctr& v)
{
  Money maxx;

  for (int i=0; i<v.size(); i++)
  {
    if (v[i]>maxx) maxx=v[i];
  }
  cout<<"Максимальный элемент = "<<maxx<<'\n';
  for (int i=0; i<v.size(); i++)
  {
    v[i]*maxx;
  }
}

vctr queToVector(que q)
{
  vctr v;

  while(!q.empty())
  { 
    v.push_back(q.front());
    q.pop();
  }

  return v;
}

que vectorToQue(vctr v)
{
  que q;

  for(int i=0;i<v.size();i++)
  {  
    q.push(v[i]);
  }

  return q;
}
