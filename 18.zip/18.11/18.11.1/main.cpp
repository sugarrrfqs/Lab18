/*
Последовательные контейнеры

Задача 1.
1.	Создать последовательный контейнер.
2.	Заполнить его элементами стандартного типа (тип указан в варианте).
3.	Добавить элементы в соответствии с заданием
4.	Удалить элементы в соответствии с заданием.
5.	Выполнить задание варианта для полученного контейнера.
6.	Выполнение всех заданий оформить в виде глобальных функций.
Задача 1
1.	Контейнер - вектор
2.	Тип элементов - float

Задание 3	
Найти минимальный элемент и добавить его на заданную позицию
контейнера	
Задание 4
Найти элементы большие среднего арифметического и
удалить их из контейнера
Задание 5
Каждый элемент домножить на максимальный элемент контейнера
*/

#include <iostream> 
#include <vector> 

using namespace std;

typedef vector<float> vctr;

vctr makeVctr(int);
void printVctr(vctr);
void addMin(vctr&, int);
void delAboveAverage (vctr&);
void multiplyByMax(vctr&);

int main()
{
  try
  {
    vctr v;
    vctr::iterator vi=v.begin();
    int n;

  // 1, 2
    cout<<"Введите длину вектора: "; 
    cin>>n; 
    if (n<1) throw 0;
    v=makeVctr(n);
    printVctr(v);
  //
  cout<<"----------------------------------------------------------------------------\n";
  // 3
    cout<<"Добавление минимального элемента на позицию N, введите N:";
    cin>>n;
    if (n<1) throw 0;
    addMin(v, n);
    printVctr(v);
  //
  cout<<"----------------------------------------------------------------------------\n";
  //4
    cout<<"Найти элементы большие среднего арифметического и удалить их из контейнера\n";
    delAboveAverage(v);
    printVctr(v);
  //
  cout<<"----------------------------------------------------------------------------\n";
  // 5
    cout<<"Каждый элемент домножить на максимальный элемент контейнера\n";
    multiplyByMax(v);
    printVctr(v);
  //
  }

  catch(int)
  {
    cout<<"Ошибка";
  }
}

vctr makeVctr(int n)
{ 
  vctr v;
  for(int i=1;i<=n;i++)
  {
    float a = i; 
    float b= a/7+(rand()%10);
    v.push_back(b);
  }
  return v;
}
 
void printVctr(vctr v)
{
  cout<<"\nВектор: ";
  for (int i=0; i<v.size(); i++) 
  {
    cout<<v[i]<<"  ";
  }
  cout<<'\n';
  cout<<endl;
}

void addMin(vctr& v, int n)
{
  float minn=v[0];

  for (int i=1; i<v.size(); i++)
  {
    if (v[i]<minn) minn=v[i];
  }

  v.insert(v.begin()+n, minn);
}

void delAboveAverage (vctr& v)
{
  float sum=0.0;
  for (int i=0; i<v.size(); i++)
  {
    sum+=v[i];
  }
  sum/=v.size();
  cout<<"Среднее = "<<sum<<'\n'<<"Элементы, больше среднего: ";
  
  for (int i=0; i<v.size(); i++)
  {
    if (v[i]>sum) 
    {
      cout<<v[i]<<' ';
      v.erase (v.begin()+i);
    }
  }
}

void multiplyByMax(vctr& v)
{
  float maxx=0.0;

  for (int i=1; i<v.size(); i++)
  {
    if (v[i]>maxx) maxx=v[i];
  }
  cout<<"Максимальный элемент = "<<maxx<<'\n';
  for (int i=0; i<v.size(); i++)
  {
    v[i]*=maxx;
  }
}