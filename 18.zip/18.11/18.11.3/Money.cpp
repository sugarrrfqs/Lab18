#include "Money.h"
#include <iostream>

using namespace std;

Money &Money::operator--()
{
	kop = 0;
	return *this;
}

Money Money::operator--(int)
{
	Money m(rub, kop);
	kop = 0;
	return m;
}

bool Money::operator==(Money &m)
{
	if (m.rub == rub && m.kop == kop)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Money::operator==(int&m)
{
	if (rub == m) return true;
	else return false;
}

Money&Money::operator=(const Money&t)
{
if(&t==this) return *this; 
rub=t.rub;
kop=t.kop; 
return *this;
}

bool Money::operator!=(Money &m)
{
  if (m.rub==rub && m.kop==kop)
  {
    return false;
  }
  else 
  {
    return true;
  }
}

bool Money::operator >(Money&m)
{
	if (rub < m.rub)
	{
		return false;
	}
	if (rub > m.rub)
	{
		return true;
	}
	if (rub == m.rub)
	{
		if (kop > m.kop)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
  return false;
}

bool Money::operator <(Money&m)
{
	if (rub > m.rub)
	{
		return false;
	}
	if (rub < m.rub)
	{
		return true;
	}
	if (rub == m.rub)
	{
		if (kop < m.kop)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
  return false;
}
	
Money& Money::operator+(Money& m)
{
  rub=rub+m.rub;
  if (kop+m.kop>=100)
  {
    kop=kop+m.kop-100;
    rub++;
  }
  else 
  {
    kop=kop+m.kop;
  }
  return (*this);
}

Money& Money::operator*(Money&m)
{
  rub=rub*m.rub;
  if (kop*m.kop>=100)
  {
    rub=rub+kop*m.kop/100;
    kop=(kop*m.kop)%100;
  }
  else
  {
    kop=kop*m.kop;
  }
  return (*this);
}

Money& Money::operator/(int k)
{
  rub=rub/k;
  kop=kop/k;
  return (*this);
}

istream&operator >> (istream&in, Money& m)
{
	cout << "Рубли: ";
	in >> m.rub;
	cout << "Копейки: ";
	in >> m.kop;
	return in;
}

ostream&operator<<(ostream&out, const Money&m)
{
	return (out << m.rub << "," << m.kop);
}