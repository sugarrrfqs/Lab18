#pragma once 
#include <vector> 
#include <iostream> 

using namespace std;

template<class T> 
class Vector
{
      vector <T> v;
      

  public:
      int len;
      Vector(); 
      Vector(int n);
      void Print();
      ~Vector(void);
      void addMin(int);
      void delAboveAverage ();
      void multiplyByMax();
};

template <class T> 
Vector<T>::Vector()
{
  len=0;
}

template <class T> 
Vector<T>::Vector(int n)
{
  len=0;
  for(int i=0;i<n;i++)
  {
    T c;
    cin>>c;
    v.push_back(c);
  }
  len=v.size();
}

template <class T>
Vector<T>::~Vector(void)
{}

template <class T> 
void Vector<T>::Print()
{
  cout<<"\nВектор: ";
  for(int i=0; i<v.size(); i++) cout<<v[i]<<"	 ";
  cout<<'\n';
}

template <class T> 
void Vector<T>::addMin(int n)
{
  T minn;
  minn=v[0];

  for (int i=1; i<v.size(); i++)
  {
    if (v[i]<minn) minn=v[i];
  }
  v.insert(v.begin()+n, minn);
}

template <class T>
void Vector<T>::delAboveAverage()
{
  T sum;
  for (int i=0; i<v.size(); i++)
  {
    sum+v[i];
  }
  sum/v.size();
  cout<<"Среднее = "<<sum<<'\n'<<"Элементы, больше среднего: ";
  
  for (int i=0; i<v.size(); i++)
  {
    if (v[i]>sum) 
    {
      cout<<v[i]<<' ';
      v.erase (v.begin()+i);
      i--;
    }
  }
}

template <class T>
void Vector<T>::multiplyByMax()
{
  T maxx;

  for (int i=1; i<v.size(); i++)
  {
    if (v[i]>maxx) maxx=v[i];
  }
  cout<<"Максимальный элемент = "<<maxx<<'\n';
  for (int i=0; i<v.size(); i++)
  {
    v[i]*maxx;
  }
}