/*
Последовательные контейнеры

Задача 2.
1.	Создать последовательный контейнер.
2.	Заполнить его элементами пользовательского типа (тип указан в варианте). Для пользовательского типа перегрузить необходимые операции.
3.	Добавить элементы в соответствии с заданием
4.	Удалить элементы в соответствии с заданием.
5.	Выполнить задание варианта для полученного контейнера.
6.	Выполнение всех заданий оформить в виде глобальных функций.
Задача 2
Тип элементов Money (см. лабораторную работу №3).

Задание 3	
Найти минимальный элемент и добавить его на заданную позицию
контейнера	
Задание 4
Найти элементы большие среднего арифметического и
удалить их из контейнера
Задание 5
Каждый элемент домножить на максимальный элемент контейнера
*/
#include <iostream> 
#include <vector> 
#include <cstdlib>
#include "Money.h"

using namespace std;

typedef vector<Money> vctr;

vctr makeVctr(int);
void printVctr(vctr);
void addMin(vctr&, int);
void delAboveAverage (vctr&);
void multiplyByMax(vctr&);

int main()
{
  try
  {
    vctr v;
    vctr::iterator vi=v.begin();
    int n;
  // 1, 2
    cout<<"Введите длину вектора: "; 
    cin>>n; 
    if (n<1) throw 0;
    v=makeVctr(n);
    printVctr(v);
  //
  cout<<"----------------------------------------------------------------------------\n";
  
  // 3
    cout<<"Добавление минимального элемента на позицию N, введите N:";
    cin>>n;
    if (n<1) throw 0;
    addMin(v, n);
    printVctr(v);
  //
  cout<<"----------------------------------------------------------------------------\n";
  
  //4
    cout<<"Найти элементы большие среднего арифметического и удалить их из контейнера\n";
    delAboveAverage(v);
    printVctr(v);
  //
  cout<<"----------------------------------------------------------------------------\n";
  // 5
    cout<<"Каждый элемент домножить на максимальный элемент контейнера\n";
    multiplyByMax(v);
    printVctr(v);
  //
  
  }

  catch(int)
  {
    cout<<"Ошибка";
  }
}

vctr makeVctr(int n)
{ 
  vctr v;
  for(int i=0;i<n;i++)
  {
    long a = rand()%100; 
    int b = rand()%100;
    Money c(a,b);
    v.push_back(c);
  }
  return v;
}
 
void printVctr(vctr v)
{
  cout<<"\nВектор: ";
  for (int i=0; i<v.size(); i++) 
  {
    cout<<v[i]<<"  ";
  }
  cout<<'\n';
  cout<<endl;
}

void addMin(vctr& v, int n)
{
  Money minn;
  minn=v[0];

  for (int i=1; i<v.size(); i++)
  {
    if (v[i]<minn) minn=v[i];
  }
  v.insert(v.begin()+n, minn);
}

void delAboveAverage (vctr& v)
{
  Money sum;
  for (int i=0; i<v.size(); i++)
  {
    sum+v[i];
  }
  sum/v.size();
  cout<<"Среднее = "<<sum<<'\n'<<"Элементы, больше среднего: ";
  
  for (int i=0; i<v.size(); i++)
  {
    if (v[i]>sum) 
    {
      cout<<v[i]<<' ';
      v.erase (v.begin()+i);
      i--;
    }
  }
}

void multiplyByMax(vctr& v)
{
  Money maxx;

  for (int i=0; i<v.size(); i++)
  {
    if (v[i]>maxx) maxx=v[i];
  }
  cout<<"Максимальный элемент = "<<maxx<<'\n';
  for (int i=0; i<v.size(); i++)
  {
    v[i]*maxx;
  }
}
