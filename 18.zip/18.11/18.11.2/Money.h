#pragma once

#include <iostream>

using namespace std;


class Money
{
	long rub;
	int kop;

public:

	Money()
	{
		rub = 0;
		kop = 0;
	}

	Money(long r, int k)
	{
		if (k<100)
		{
			rub = r;
			kop = k;
		}
		else
		{
			rub = r + k / 100;
			kop = k % 100;
		}

		if (r < 0 || k < 0)
		{
			cout << "Ошибка, количество рублей и копеек должно быть > 0";
			rub = 0;
			kop = 0;
		}
	}
  
  Money& operator--();
	Money operator--(int);
	Money&operator=(const Money&);
	bool operator==(Money&);
	bool operator==(int&);
  bool operator!=(Money &);
	bool operator >(Money&);
	bool operator <(Money&);
  Money& operator+(Money&);
  Money& operator*(Money&);
  Money& operator/(int);
  
	~Money() {}
  friend istream& operator >> (istream&in, Money&m);
	friend ostream& operator<<(ostream&out, const Money&m);
};
