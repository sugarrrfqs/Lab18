#pragma once

#include "Object.h"
#include "Print.h"
#include "Magazin.h"


class List
{
  public:
  List(){};
  List(int); 
  ~List(void); 
  void Add();
  void Del();
  void Show();
  int operator()();

  protected:
  Object**beg;
  int size=0;
  int cur;
};
