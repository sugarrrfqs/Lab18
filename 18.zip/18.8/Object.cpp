#include "Object.h"

Object::Object(void)
{
}

Object::~Object(void)
{
}
