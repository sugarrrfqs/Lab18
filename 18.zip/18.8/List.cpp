#include "List.h"

using namespace std;

List::~List(void)
{
  if(beg!=0)delete [] beg; 
  beg=0;
}

List::List(int n)
{
  if (n>0)
  {
  beg=new Object*[n]; cur=0;
  size=n;
  }
  else 
  {
    cout<<"Невозможно создать список указанной длины\n";
  }
}

void List::Add ()
{
  Object*p;
  if (size==0)
  {
    cout<<"Длина списка равна 0\n";
  }
  else
  {
    
  
  cout<<"1.Print"<<endl; 
  cout<<"2.Magazin"<<endl;
  int y; 
  cin>>y;

  if(y==1)
  {
    Print*a=new (Print);
    a->Input();
    p=a;

    if(cur<size)
    {
      beg[cur]=p;
      cur++;
    }
  }
  else
  if(y==2) 
  {
 
    Magazin *b=new Magazin; b->Input();
    p=b;

    if(cur<size)
    {
      beg[cur]=p; cur++;
    }
  }
  cout<<"Элемент добавлен\n";
  }
}

void List::Show()
{
  if(cur==0)cout<<"Длина списка равна 0\n";
  Object **p=beg;
  for(int i=0;i<cur;i++)
  {
    (*p)->Show();
    p++;
  }
}

int List::operator ()()
{
  return cur;
}

void List::Del()
{
  if (size>0 and cur>0)
  {
    cout<<"Элемент удален\n";
    cur--;
  }
    
  else
  {
    if (size<1)
    {
    cout<<"Длина списка равна 0\n";
  }
  if (cur<1)
  {
    cout<<"Список пуст\n";
  }
  }
    
}
