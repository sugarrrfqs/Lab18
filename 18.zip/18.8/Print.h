#pragma once

#include <iostream>
#include "Object.h"

using namespace std;

class Print: public Object
{
  public:

  string title;
  string autor;

  Print()
  {
    title="";
    autor="";
  }

  Print(string t, string a)
  {
    title=t;
    autor=a;
  }

  string getTitle()
  {
    return title;
  }

  string getAutor()
  {
    return autor;
  }

  void setTitle(string t)
  {
    title=t;
  }

  void setAutor(string a)
  {
    autor=a;
  }

  void Input ()
  {
    cout<<"\ntitle: ";
    cin>>title;
    cout<<"autor: ";
    cin>>autor;
  }

  void Show()
  {
    cout<<"\ntitle: "<<title;
    cout<<"\nautor: "<<autor;
    cout<<"\n";
  }

  ~Print(){};

};