#pragma once

#include <iostream>
#include "Print.h"

using namespace std;

class Magazin:public Print
{
  public:

  int numberOfPages;

  Magazin()
  {
    title="";
    autor="";
    numberOfPages=0;
  }

  Magazin(string t, string a, int s)
  {
    title=t;
    autor=a;
    numberOfPages=s;
  }

  int getNumberOfPages()
  {
    return numberOfPages;
  }

  void setNumberOfPages(int n)
  {
    numberOfPages=n;
  }

  void Input ()
  {
    cout<<"title: ";
    cin>>title;
    cout<<"autor: ";
    cin>>autor;
    cout<<"numberOfPages: ";
    cin>>numberOfPages;
  }

  void Show()
  {
      cout<<"\ntitle: "<<title;
      cout<<"\nautor: "<<autor;
      cout<<"\nnumberOfPages: "<<numberOfPages;
      cout<<"\n";
  }
};