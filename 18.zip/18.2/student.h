#include <iostream> 
#include <string> 
using namespace std; 
class Student
{
//атрибуты
  string name; 
  string subj; 
  int mark;

  public:
  Student();//конструктор без параметров
  Student(string, string, int);//конструктор с параметрами 
  Student(const Student&);//конструктор копирования
  ~Student();//деструктор
  string get_name();//селектор
  void set_name(string);//модификатор 
  string get_subj();//селектор
  void set_subj(string); //модификатор 
  int get_mark();//селектор
  void set_mark(int); //модификатор 
  void show();//просмотр атрибутов
};
