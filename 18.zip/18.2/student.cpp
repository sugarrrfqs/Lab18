#include "Student.h" 
#include <iostream> 
#include <string> 

using namespace std;

//конструктор без параметров 
Student::Student()
{
name=""; subj=""; mark=0;

}

//конструктор с параметрами 
Student::Student(string N, string K, int S)
{
  name=N;
  subj=K;
  mark=S;
}

//конструктор копирования 
Student::Student(const Student &t)
{
name=t.name; subj=t.subj; mark=t.mark;
 

}
//деструктор 
Student::~Student()
{
}
//селекторы
string Student::get_name()
{
return name;
}
string Student::get_subj()
{
return subj;
}
int Student::get_mark()
{
return mark;
}
//модификаторы
void Student::set_name(string N)
{
name=N;
}
void Student::set_subj(string K)
{
subj=K;
}
void Student::set_mark(int S)
{
mark=S;
}
//метод для просмотра атрибутов 
void Student::show()
{
cout<<"name :"<<name<<endl; cout<<"subject :"<<subj<<endl; cout<<"mark :"<<mark<<endl;
}
