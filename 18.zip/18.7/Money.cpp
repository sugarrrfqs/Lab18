#include "Money.h"
#include <iostream>

using namespace std;

Money &Money::operator--()
{
	kop = 0;
	return *this;
}

Money Money::operator--(int)
{
	Money m(rub, kop);
	kop = 0;
	return m;
}

bool Money::operator==(Money &m)
{
	if (m.rub == rub && m.kop == kop)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Money::operator==(int&m)
{
	if (rub == m) return true;
	else return false;
}

Money Money::operator= (int&m)
{
	rub = m;
	return (*this);
}

bool Money::operator!=(Money &m)
{
  if (m.rub==rub && m.kop==kop)
  {
    return false;
  }
  else 
  {
    return true;
  }
}

bool Money::operator >(Money&m)
{
	if (rub < m.rub)
	{
		return false;
	}
	if (rub > m.rub)
	{
		return true;
	}
	if (rub == m.rub)
	{
		if (kop > m.kop)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

bool Money::operator <(Money&m)
{
	if (rub > m.rub)
	{
		return false;
	}
	if (rub < m.rub)
	{
		return true;
	}
	if (rub == m.rub)
	{
		if (kop < m.kop)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
	
Money Money::operator+(Money& m)
{
  Money tmp;
  tmp.rub=rub+m.rub;
  if (kop+m.kop>=100)
  {
    tmp.kop=kop+m.kop-100;
    tmp.rub++;
  }
  else 
  {
    tmp.kop=kop+m.kop;
  }
  return tmp;
}

istream&operator >> (istream&in, Money& m)
{
	cout << "Рубли: ";
	in >> m.rub;
	cout << "Копейки: ";
	in >> m.kop;
	return in;
}

ostream&operator<<(ostream&out, const Money&m)
{
	return (out << m.rub << "," << m.kop);
}