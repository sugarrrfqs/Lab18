#pragma once

#include <iostream>

using namespace std;

template <class T>
class Mnvo
{
    public:

	Mnvo(int length, T k);
	Mnvo(Mnvo<T>&);
	~Mnvo();
	Mnvo& operator = (Mnvo<T>&);
	int operator () ();
	T& operator [] (int);
	Mnvo operator - (Mnvo<T>);
	friend istream& operator >> <>(istream&in, Mnvo<T>&a);
	friend ostream& operator << <>(ostream&out, const Mnvo<T>&a);

	int size;
	T*data;
  
};


template <class T>
Mnvo<T>::Mnvo(int s, T k)
{
	size = s;
	data = new T[size];
	for (int i = 0; i<size; i++) data[i] = k;
}

template <class T>
Mnvo<T>::Mnvo(Mnvo& a)
{
	size = a.size;
	data = new T[size];
	for (int i = 0; i<size; i++) data[i] = a.data[i];
}

template <class T>
Mnvo<T>::~Mnvo()
{
	delete[]data;
	data = 0;
}

template <class T>
Mnvo<T> &Mnvo<T>::operator=(Mnvo<T>&a)
{
	if (this == &a) return *this;
	size = a.size;
	if (data != 0) delete[]data;
	data = new T[size];
	for (int i = 0; i<size; i++) data[i] = a.data[i];
	return *this;
}

template <class T>
T& Mnvo<T>::operator [] (int index)
{
	if (index<size) return data[index];
	else cout << "\nIndex>size";
	return data[0];
}

template <class T>
int Mnvo<T>::operator ()()
{
	return size;
}

template <class T>
Mnvo<T> Mnvo<T>::operator - (Mnvo<T> a)
{
	bool f;
	int y = (*this).size, i;
	
    for (i = 0; i<a.size; i++)
	{
		f = false;
		for (int j = 0; j<(*this).size; j++)
		{
			if (a[i] == (*this)[j] && !f)
			{
				f = true;
				for (int p = j+1; p < (*this).size; p++)
				{
				    (*this)[p-1] = (*this)[p];
                }
				size--;
			}
		}
	}
	return (*this);
}

template <class T>
ostream&operator << (ostream&out, const Mnvo<T>&a)
{
	for (int i = 0; i<a.size; ++i)
	{
		out << a.data[i] << " ";
	}
	return out;
}

template <class T>
istream&operator >> (istream&in, Mnvo<T>&a)
{
	for (int i = 0; i<a.size; ++i) in >> a.data[i];
	return in;
}
