#include <bits/stdc++.h>
#include "pair.h"

using namespace std;

void Pair::Init (double F, double S)
{
  first=F;
  second=S;
}

void Pair::Read()
{
  cout<<"\nfirst: ";
  cin>>first;
  cout<<"\nsecond: ";
  cin>>second;
}

void Pair::Show()
{
  cout<<"\nfirst: "<<first;
  cout<<"\nsecond: "<<second;
  cout<<'\n';
}

double Pair::Hipo()
{
  return sqrt(first*first+second*second);
}