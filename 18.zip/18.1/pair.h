class Pair
{
  public:
  double first;
  double second;
  void Init (double, double);
  void Read();
  void Show();
  double Hipo();
};