#include "Money.h"
#include <iostream>

using namespace std;

Money &Money::operator--()
{
  kop=0;
  return *this;
}

Money Money::operator--(int)
{
  Money m (rub, kop);
  kop=0;
  return m;
}

bool Money::operator==(Money &m)
{
  if (m.rub==rub && m.kop==kop)
  {
    return true;
  }
  else 
  {
    return false;
  }
}

istream&operator>>(istream&in, Money& m) 
{
  cout<<"Рубли: ";
  in>>m.rub;
  cout<<"Копейки: ";
  in>>m.kop;
  return in;
} 

ostream&operator<<(ostream&out, const Money&m)
{
  return (out<<m.rub<<","<<m.kop);
}