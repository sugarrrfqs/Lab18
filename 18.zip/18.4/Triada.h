#pragma once

#include <iostream>

using namespace std;

class Triada
{
  public:
  
  int first;
  int second;
  int third;

  Triada()
  {
    first=0;
    second=0;
    third=0;
  }

  Triada(int f, int s, int t)
  {
    first=f;
    second=s;
    third=t;
  }

  Triada(Triada &tr)
  {
    first=tr.first;
    second=tr.second;
    third=tr.third;
  }

  ~Triada(){}

  void inc_first()
  {
    first++;
  }

  void inc_second()
  {
    second++;
  }

  void inc_third()
  {
    third++;
  }

  void set_first (int f)
  {
    first=f;
  }

  void set_second (int s)
  {
    second=s;
  }

  void set_third (int t)
  {
    third=t;
  }
  
  Triada operator=(Triada&);
  
  friend istream& operator>>(istream&in, Triada&m); 
  friend ostream& operator<<(ostream&out, const Triada&m);


};

