#include "Triada.h"
#include <iostream>

using namespace std;

Triada Triada::operator=(Triada &tr)
  {
    Triada n;
    first=tr.first;
    second=tr.second;
    third=tr.third;
    return n;
  }

istream&operator>>(istream&in, Triada& m) 
{
  cout<<"1: ";
  in>>m.first;
  cout<<"2: ";
  in>>m.second;
  cout<<"3: ";
  in>>m.third;
  return in;
} 

ostream&operator<<(ostream&out, const Triada&m)
{
  return (out<<m.first<<","<<m.second<<","<<m.third);
}