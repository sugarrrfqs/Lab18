#include "Date.h"
#include <iostream>

using namespace std;



istream&operator>>(istream&in, Date& m) 
{
  cout<<"Число: ";
  in>>m.first;
  cout<<"Месяц: ";
  in>>m.second;
  cout<<"Год: ";
  in>>m.third;
  return in;
} 

ostream&operator<<(ostream&out, const Date&m)
{
  return (out<<m.first<<"."<<m.second<<"."<<m.third);
}